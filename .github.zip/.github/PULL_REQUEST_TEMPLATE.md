## Scopo
<!-- Cosa fa questo PR? -->

## Tipo di cambiamento
- [ ] Bugfix
- [ ] Feature
- [ ] Refactor / chore
- [ ] CI/CD

## Verifiche
- [ ] Build e test locali passano
- [ ] Copertura non regredisce (o spiegazione)
- [ ] Documentazione aggiornata (se serve)

## Note
