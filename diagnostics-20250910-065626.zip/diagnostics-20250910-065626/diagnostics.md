# Progesi Diagnostics 20250910-065626

## Repo
- / ()
- Default branch: 
- URL: 

## Workflows

## Recent runs (global)
- [17604593470] CI | CI | chore/ci-trx -> in_progress (09/10/2025 05:55:48)
- [17604502616] CI | CI | chore/ci-trx -> success (09/10/2025 05:51:55)
- [17604502548] CI | ci: enable workflow_dispatch + stable format + TRX + coverage | chore/ci-trx -> cancelled (09/10/2025 05:49:45)
- [17604232002] CI | CI | chore/ci-trx -> failure (09/10/2025 05:35:24)
- [17603619454] CI | CI | chore/maintenance-ci-hardening -> failure (09/10/2025 04:57:53)
- [17573102158] CodeQL | chore: maintenance (editorconfig, CODEOWNERS, release hardening) | chore/maintenance-ci-hardening -> failure (09/09/2025 05:55:20)
- [17573102151] CI | chore: maintenance (editorconfig, CODEOWNERS, release hardening) | chore/maintenance-ci-hardening -> failure (09/09/2025 05:51:22)
- [17550577093] CI | CI | chore/ci-fix-windows-x64 -> success (09/08/2025 12:23:19)
- [17550536658] CI | CI: Windows x64 tests + coverage | chore/ci-fix-windows-x64 -> success (09/08/2025 12:22:08)
- [17550535886] CI | CI | chore/ci-fix-windows-x64 -> success (09/08/2025 12:21:52)

## Runs per workflow (ultimi)

## Ultimo run fallito
- ID: 17604232002 — CI — CI
- Branch: chore/ci-trx
- Esito: failure
- Log: run.log.txt
